/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.menu.spi;

/**
 * A menu or toolbar item.
 */
public final class Item extends Positionable
{
  private String _radioGroupId;

  public Item( String actionId )
  {
    super( actionId );
  }

  void setRadioGroupID( String radioGroupID )
  {
    _radioGroupId = radioGroupID;
  }

  public String getRadioGroupID()
  {
    return _radioGroupId;
  }

  public String getActionID()
  {
    return getID();
  }
}
