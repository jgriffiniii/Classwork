/*
 * @(#)IfStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An if statement. JLS3 14.9. <p/>
 *
 * @author Andy Yu
 * */
public interface IfStatementT
  extends ConditionalStatementT
{
  // ----------------------------------------------------------------------

  /**
   * @return The else clause if present.
   */
  public ElseClauseT getElseClause();
}
