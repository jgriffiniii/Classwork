/*
 * @(#)ClassInitializerT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A static or instance initializer block for a class. <p/>
 *
 * @author Andy Yu
 * */
public interface ClassInitializerT
  extends MemberT
{
  // ----------------------------------------------------------------------

  static final ClassInitializerT[] EMPTY_ARRAY =
    new ClassInitializerT[ 0 ];


  // ----------------------------------------------------------------------
}
