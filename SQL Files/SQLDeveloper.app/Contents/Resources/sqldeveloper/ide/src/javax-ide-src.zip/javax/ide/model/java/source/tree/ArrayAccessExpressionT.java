/*
 * @(#)ArrayAccessExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An array access expression. Example: <code>array[0]</code>. <p/>
 *
 * @author Andy Yu
 * */
public interface ArrayAccessExpressionT
  extends DereferenceExpressionT
{
}
