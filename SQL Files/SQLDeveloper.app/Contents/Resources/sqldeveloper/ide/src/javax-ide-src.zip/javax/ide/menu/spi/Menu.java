/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.menu.spi;
import javax.ide.util.IconDescription;

public final class Menu extends SectionContainer
{
  private String _label;
  private char _mnemonic;
  private String _tooltip;
  private IconDescription _icon;
  private Float _defaultSection;

  Menu( String id )
  {
    super( id );
  }

  public String getLabel()
  {
    return _label;
  }

  void setLabel( String label )
  {
    _label = label;
  }

  public char getMnemonic()
  {
    return _mnemonic;
  }

  void setMnemonic( char c )
  {
    _mnemonic = c;
  }

  public String getTooltip()
  {
    return _tooltip;
  }

  void setTooltip( String tooltip )
  {
    _tooltip = tooltip;
  }

  public IconDescription getIcon()
  {
    return _icon;
  }

  void setIcon( IconDescription icon )
  {
    _icon = icon;
  }

  public void setDefaultSection( Float defaultSection )
  {
    this._defaultSection = defaultSection;
  }

  public Float getDefaultSection()
  {
    return _defaultSection;
  }
}
