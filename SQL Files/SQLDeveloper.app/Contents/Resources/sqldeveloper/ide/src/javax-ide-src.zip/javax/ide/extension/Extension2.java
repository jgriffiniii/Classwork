package javax.ide.extension;

/**
 * JSR-198 2.0 version of the Extension interface.
 * 
 * @since 2.0
 */
@Deprecated
public interface Extension2 extends Extension
{
  /**
   * Returns the type of classloader this extension prefers to be loaded in.
   * 
   * @return the type of loader this extension prefers to be loaded in.
   */
  public LoaderType getPreferredLoader();
}
